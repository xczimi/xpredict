package com.samsung.spensdk.example.contextaware_general;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

import com.samsung.spen.lib.input.SContextAppManager;
import com.samsung.spensdk.example.R;

public class SPen_Example_ContextAware extends Activity {

	private int mContextIdentifierIndex = 0;
	private final int [] mContextIdentifier = new int[]{
		SContextAppManager.CONTEXT_ID_RECENT,
		SContextAppManager.CONTEXT_ID_RECENT_SPEN,
		SContextAppManager.CONTEXT_ID_RECENT_EARPHONE,
	};
		
	public SPen_Example_ContextAwareCursorAdapter mContextAppListAdapter=null;
	private Context mContext = null;
	private Cursor mContextCursor = null;
	
	private Spinner mSpinnerContext = null;
	private ListView mContextAppListView = null;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.general_purpose_ca);
		mContext = this;
		
		// Check Context Aware Support
		if(SContextAppManager.isSContextAppSupport(mContext)==false){
			Toast.makeText(mContext, "Context-Aware feature is not supported in this device.", Toast.LENGTH_LONG).show();
			finish();
		}
		
		mSpinnerContext = (Spinner) findViewById(R.id.spinner_context);
		ArrayAdapter adapterType = ArrayAdapter.createFromResource(
		             this, R.array.context_identifiers, android.R.layout.simple_spinner_item);
		adapterType.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		mSpinnerContext.setAdapter(adapterType);
		mSpinnerContext.setSelection(mContextIdentifierIndex);
		mSpinnerContext.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				// Setting 변경
				updateAppUsageList(mSpinnerContext.getSelectedItemPosition());				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
			} 
		});
		
		mContextAppListView = (ListView)findViewById(R.id.launcherList);        
	}
	
	@Override
	protected void onResume() {		
		
		
		updateAppUsageList(mContextIdentifierIndex);
		super.onResume();
	}
	
	private void updateAppUsageList(int nContextIndentifierIndex){
		if(nContextIndentifierIndex<0 || nContextIndentifierIndex>=mContextIdentifier.length)
			return;
		
		if(mContextIdentifier==null)
			return;		
		int nContextIndentifier = mContextIdentifier[nContextIndentifierIndex];
		
		mContextCursor = SContextAppManager.getContextAppList(mContext, nContextIndentifier);
		if(mContextCursor==null)
			return;
		
		//startManagingCursor(mContextCursor);
		
		mContextAppListAdapter = new SPen_Example_ContextAwareCursorAdapter( 
				mContextAppListView.getContext(),
				R.layout.general_purpose_ca_app_item, 
				mContextCursor, 
				getMatchingFieldNames(),
				getMatchingFieldLayout());
		mContextAppListView.setAdapter(mContextAppListAdapter);
	}
	
	private String[] getMatchingFieldNames() {
		return new String []{
				SContextAppManager.getFieldNameOfPackageName(),
				SContextAppManager.getFieldNameOfClassName(),
				SContextAppManager.getFieldNameOfSystemStatus(),
		};
	}
	private int [] getMatchingFieldLayout() {
		return new int[]{
				R.id.packageName,
				R.id.className, 
				R.id.systemStatus,
		};
	}
}
