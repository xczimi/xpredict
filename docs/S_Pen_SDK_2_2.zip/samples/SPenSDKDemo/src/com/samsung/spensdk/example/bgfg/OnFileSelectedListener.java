package com.samsung.spensdk.example.bgfg;

public interface OnFileSelectedListener {
	public void onSelected(String path, String fileName);
}
