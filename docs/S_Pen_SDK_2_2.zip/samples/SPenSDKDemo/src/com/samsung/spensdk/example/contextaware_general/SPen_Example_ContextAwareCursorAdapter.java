package com.samsung.spensdk.example.contextaware_general;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.samsung.spen.lib.input.SContextAppManager;
import com.samsung.spensdk.example.R;

public class SPen_Example_ContextAwareCursorAdapter  extends SimpleCursorAdapter{

	private int mLayout;
	private String [] mFrom = null;
	private int [] mTo = null;
	private Context mContext = null;
	private PackageManager pm = null; 
	
	private static final String CLASS_NAME = SContextAppManager.getFieldNameOfClassName();
	private static final String PACKAGE_NAME = SContextAppManager.getFieldNameOfPackageName();
	private static final String SYSTEM_STATUS_NAME = SContextAppManager.getFieldNameOfSystemStatus();
	
	public SPen_Example_ContextAwareCursorAdapter(Context context, int layout, Cursor c, String[] from, int[] to)
	{
		super(context, layout, c, from, to);
		mContext = context;
		mLayout = layout;
		mFrom = from;
		mTo = to;
		
		pm = context.getPackageManager();
	}

	@Override
	public View newView(Context context, Cursor cur, ViewGroup parent)
	{
		LayoutInflater li = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		return li.inflate(mLayout, parent, false);
	}

	@Override
	public void bindView(View view, Context context, Cursor cur)
	{
		//------------------------------------------
		// The basic information 
		//------------------------------------------
		int nColumnNum = mFrom.length;
		for(int i=0; i<nColumnNum; i++)
		{
			if(mFrom[i]==null)
				continue;
			int nColumnIndex = cur.getColumnIndex(mFrom[i]);
			if(nColumnIndex>=0){
				String columnText = cur.getString(nColumnIndex);
				if(columnText==null) 
					continue;
				if(mTo[i]==0) 
					continue;
			TextView tvText = (TextView) view.findViewById(mTo[i]);
				if(tvText==null) 
					continue;
			tvText.setText(columnText);			
		}
			else {
				Log.e("SPen_Example_ContextAwareCursorAdapter", "The Cursor column for " + mFrom[i] + "is not exist");
			}
		}
		
		//------------------------------------------
		// Get Launch Item Value 
		//------------------------------------------
		String tempClassName = null;
		String tempPackageName = null;
		String tempSystemStatus = null;
		
		
		for(int i=0; i<nColumnNum; i++)
		{
			if(mFrom[i].equals(PACKAGE_NAME))
				tempPackageName = cur.getString(cur.getColumnIndex(mFrom[i]));
			else if(mFrom[i].equals(CLASS_NAME))
				tempClassName = cur.getString(cur.getColumnIndex(mFrom[i]));
			else if(mFrom[i].equals(SYSTEM_STATUS_NAME))
				tempSystemStatus = cur.getString(cur.getColumnIndex(mFrom[i]));
		}
		
		final String curPackageName = tempPackageName;
		final String curClassName = tempClassName;
		final String curSystemStatus = tempSystemStatus;
		
		//------------------------------------------
		// Set UI Setting
		//------------------------------------------
		// Favorite onClickListner(Toggle)
		RelativeLayout rl = (RelativeLayout)view.findViewById(R.id.imgLayout);		
		rl.setFocusable(false);		
		
		
		// Package name & Title
		if(curClassName!=null && curPackageName!=null){
			ContextAppData item = new ContextAppData(curClassName, curPackageName);
			
			if(item!=null){ 
				// Check Valid
				if(item.resolveLaunchItem(pm)){
					// Thumbnail
					ImageView imgView = (ImageView) view.findViewById(R.id.itemImg);
					imgView.setImageBitmap(item.getIcon());
					
					// Title (app name)
					String titleName = item.getTitleName();
					TextView tvTitle = (TextView) view.findViewById(R.id.titleName);
					tvTitle.setText(titleName);
					
					// System status
					TextView tvSystemStatus = (TextView)view.findViewById(R.id.systemStatus);
					if(curSystemStatus!=null){
						tvSystemStatus.setText("System status : " + curSystemStatus);
						tvSystemStatus.setVisibility(View.VISIBLE);
					}
					else{
						tvSystemStatus.setVisibility(View.GONE);
					}
					
					// Package Name
					TextView tvPackageName = (TextView)view.findViewById(R.id.packageName);
					if(curPackageName !=null){
						tvPackageName.setText("Package : " +curPackageName);
						tvPackageName.setVisibility(View.VISIBLE);
					}
					else{
						tvPackageName.setVisibility(View.GONE);
					}
					
					// Class Name
					TextView tvClassName = (TextView)view.findViewById(R.id.className);
					if(curClassName !=null){
						tvClassName.setText("Class : " +curClassName);
						tvClassName.setVisibility(View.VISIBLE);
					}
					else{
						tvClassName.setVisibility(View.GONE);
					}
				}
			}
		}
		
		
		// Set Launcher 
		LinearLayout ll = (LinearLayout)view.findViewById(R.id.appInfo);		
		ll.setFocusable(false);		
		ll.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(mContext!=null){
					Intent intentApp = new Intent(Intent.ACTION_MAIN);
					intentApp.setComponent(new ComponentName(curPackageName, curClassName));
			    	intentApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);	
			    	intentApp.addCategory(Intent.CATEGORY_LAUNCHER);	 
			    	mContext.startActivity(intentApp);
				}
			}
		});
	}
	
	private String getDateString(long lDate){
		Date dateFormat = new Date();
		dateFormat.setTime(lDate);
		SimpleDateFormat sdf = null;
		sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm");	// 연/월/일 24시간제 (0-23)
		String strDateString = sdf.format(dateFormat);
		sdf = null;
		return strDateString;
	}
}
