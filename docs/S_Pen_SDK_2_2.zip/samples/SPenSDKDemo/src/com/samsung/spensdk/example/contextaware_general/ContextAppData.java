package com.samsung.spensdk.example.contextaware_general;

import java.util.List;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;


public class ContextAppData {
	
	private final int ICON_WIDTH = 72;
	private final int ICON_HEIGHT = 72;
	
	// Field 
	private String mClassName;
	private String mPackageName;
	
	// Extended information
	private String mTitleName;
	private Bitmap mBitmapIcon;
	
	//===============================================================
	//
	// Basic Function : Getter, Setter
	//
	//===============================================================
	public ContextAppData() { }
	public ContextAppData(String classname, String packagename) {
		setDBItem(classname, packagename);
	}
	
	public void setDBItem(String classname, String packagename) {
		setClassName(classname);
		setPackageName(packagename);
	}

	public String getPackageName() {
		return mPackageName;
	}
	public void setPackageName(String str) {
		mPackageName = str;
	}	
	public String getClassName() {
		return mClassName;
	}
	public void setClassName(String str) {
		mClassName = str;
	}
	
	public String getTitleName() {
		return mTitleName;
	}
	public void setTitleName(String str) {
		mTitleName = str;
	}
	public Bitmap getIcon() {
		return mBitmapIcon;
	}
	public void setIcon(Bitmap icon) {
		mBitmapIcon = Bitmap.createScaledBitmap(icon, ICON_WIDTH, ICON_HEIGHT, true);
	}
	
	public boolean resolveLaunchItem(PackageManager pm)
	{		
		// It receive launch intent of the corresponding package.
		Intent launchIntent = pm.getLaunchIntentForPackage(mPackageName);
		if(launchIntent==null)
			return false;
		
		//if(cnLaunch.getClassName().equals("com.android.internal.app.ResolverActivity"))
		List<ResolveInfo> list = pm.queryIntentActivities(launchIntent, 0);
		boolean bLaunchResolved = false;
		if(list!=null && list.size()>0)
			bLaunchResolved = true;
		
		// Register the class name, if the Launch Activity is not existed.
		if(bLaunchResolved==false){
			// If the contact is equal to return false. (Phone, contact the same package name)
		}
		// Otherwise, the registered class name of LauchActivity.
		else
		{
			ComponentName cnLaunch = launchIntent.getComponent();
			mClassName = cnLaunch.getClassName();	// Class name changes
		}
		
		//==============================
		// Gets the package information. 
		//==============================
		ComponentName cn = new ComponentName(mPackageName, mClassName);
		Intent baseIntent = new Intent();
		baseIntent.setComponent(cn);
		
		baseIntent.setFlags((baseIntent.getFlags()&~Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED) | Intent.FLAG_ACTIVITY_NEW_TASK);
		baseIntent.addCategory(Intent.CATEGORY_DEFAULT);
		final ResolveInfo resolveInfo = pm.resolveActivity(baseIntent, PackageManager.MATCH_DEFAULT_ONLY); 
		
		if (resolveInfo != null) 
		{               
			// Gets the activity information. 
			final ActivityInfo activityInfo = resolveInfo.activityInfo;

			// If that can not be called from external Activity.
			if(activityInfo.exported==false)	 
				return false;
			// Resolve ClassName
			if(!mClassName.equals(activityInfo.name))
			{
				mClassName = activityInfo.name; // Class name changes
			}
			
			// Resolve Title
			mTitleName = activityInfo.loadLabel(pm).toString();
			// Resolve Icon
			Drawable icon = activityInfo.loadIcon(pm);
			setIcon(drawableToBitmap(icon));	// Make proper icon image
			 
			return true;
		}
		return false;
	}
	
	Bitmap drawableToBitmap(Drawable d){
		int nBitmapWidth = d.getMinimumWidth();
    	int nBitmapHeight= d.getMinimumHeight();
    	Bitmap bitmap = Bitmap.createBitmap(nBitmapWidth, nBitmapHeight, Bitmap.Config.ARGB_8888);
    	Canvas canvas = new Canvas(bitmap);
    	d.setBounds(0, 0, nBitmapWidth, nBitmapHeight);
    	d.draw(canvas);
    	return Bitmap.createScaledBitmap(bitmap, ICON_WIDTH, ICON_HEIGHT, true);
    	//return bitmap;
	}
	
	
}

