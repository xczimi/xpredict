package com.samsung.spensdk.example.tools;

public interface OnFileSelectedListener {
	public void onSelected(String path, String fileName);
}
